import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

import 'add_task.dart';
import 'description.dart'; // Import Description screen
import 'acc.dart'; // Import Account screen
import 'appbar.dart'; // Import CustomAppBar

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  String uid = '';
  late Query _todoQuery;
  late Query _doingQuery;
  late Query _doneQuery;

  @override
  void initState() {
    super.initState();
    getUid();
    _todoQuery = FirebaseFirestore.instance
        .collection('tasks')
        .doc(uid)
        .collection('mytasks')
        .where('category', isEqualTo: 'TODO');
    _doingQuery = FirebaseFirestore.instance
        .collection('tasks')
        .doc(uid)
        .collection('mytasks')
        .where('category', isEqualTo: 'DOING');
    _doneQuery = FirebaseFirestore.instance
        .collection('tasks')
        .doc(uid)
        .collection('mytasks')
        .where('category', isEqualTo: 'DONE');
  }

  getUid() async {
    FirebaseAuth auth = FirebaseAuth.instance;
    User? user = auth.currentUser;
    setState(() {
      uid = user!.uid;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        appName: 'TO DO APP',
        slogan: 'All in one!',
        actions: [
          IconButton(
            icon: Icon(Icons.account_circle),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => Account()),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: Row(
              children: [
                Expanded(
                  child: _buildColumn(
                      "TODO", _todoQuery, Color.fromARGB(255, 82, 125, 160)),
                ),
                Expanded(
                  child: _buildColumn(
                      "DOING", _doingQuery, Color.fromARGB(255, 104, 164, 105)),
                ),
                Expanded(
                  child: _buildColumn(
                      "DONE", _doneQuery, Color.fromARGB(255, 175, 149, 110)),
                ),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add, color: Colors.white),
        backgroundColor: Theme.of(context).primaryColor,
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => AddTask()),
          );
        },
      ),
    );
  }

  Widget _buildColumn(String title, Query query, Color color) {
    return Container(
      padding: EdgeInsets.all(10),
      color: color, // Set column color
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 10),
          StreamBuilder(
            stream: query.snapshots(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return CircularProgressIndicator();
              } else {
                int itemCount = snapshot.data?.docs.length ?? 0;
                return Text("$itemCount tasks");
              }
            },
          ),
          SizedBox(height: 10),
          Expanded(
            child: StreamBuilder(
              stream: query.snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return CircularProgressIndicator();
                } else {
                  final docs = snapshot.data!.docs;
                  return ListView.builder(
                    itemCount: docs.length,
                    itemBuilder: (context, index) {
                      var data = docs[index].data() as Map<String, dynamic>;
                      var deadline = data.containsKey('deadline') &&
                              data['deadline'] != null
                          ? (data['deadline'] as Timestamp).toDate()
                          : DateTime.now();
                      String formattedDeadline =
                          DateFormat('dd/MM/yyyy').format(deadline);
                      return InkWell(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => Description(
                                title: data['title'] ?? '',
                                description: data['description'] ?? '',
                                uid: uid,
                                taskId: docs[index].id,
                              ),
                            ),
                          );
                        },
                        child: Container(
                          margin: EdgeInsets.only(bottom: 10),
                          decoration: BoxDecoration(
                            color: Color.fromARGB(255, 51, 56, 55),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          height: 90,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Checkbox(
                                value: data['completed'] ?? false,
                                onChanged: (value) {
                                  _updateTaskStatus(docs[index].id, value);
                                },
                              ),
                              if (title == "TODO")
                                IconButton(
                                  icon: Icon(Icons.arrow_forward),
                                  onPressed: () {
                                    _moveToDoing(docs[index].id);
                                  },
                                ),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(left: 20),
                                    child: Text(
                                      data['title'] ?? '',
                                      style: GoogleFonts.roboto(fontSize: 20),
                                    ),
                                  ),
                                  SizedBox(height: 5),
                                  Padding(
                                    padding: const EdgeInsets.only(left: 20),
                                    child: Text(
                                      'DEADLINE: $formattedDeadline',
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                ],
                              ),
                              IconButton(
                                icon: Icon(Icons.delete),
                                onPressed: () async {
                                  await FirebaseFirestore.instance
                                      .collection('tasks')
                                      .doc(uid)
                                      .collection('mytasks')
                                      .doc(docs[index].id)
                                      .delete();
                                },
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  );
                }
              },
            ),
          ),
        ],
      ),
    );
  }

  void _updateTaskStatus(String taskId, bool? completed) async {
    await FirebaseFirestore.instance
        .collection('tasks')
        .doc(uid)
        .collection('mytasks')
        .doc(taskId)
        .update({'completed': completed});

    if (completed != null && completed) {
      // Move task to DONE
      await FirebaseFirestore.instance
          .collection('tasks')
          .doc(uid)
          .collection('mytasks')
          .doc(taskId)
          .update({'category': 'DONE'});
    }
  }

  void _moveToDoing(String taskId) async {
    await FirebaseFirestore.instance
        .collection('tasks')
        .doc(uid)
        .collection('mytasks')
        .doc(taskId)
        .update({'category': 'DOING'});
  }
}
