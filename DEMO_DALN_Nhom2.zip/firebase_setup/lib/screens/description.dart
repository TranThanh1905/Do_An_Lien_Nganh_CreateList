import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

import 'edit.dart'; // Import EditTask screen
import 'appbar.dart'; // Import CustomAppBar

class Description extends StatelessWidget {
  final String title;
  final String description;
  final String uid;
  final String taskId;

  const Description({
    required this.title,
    required this.description,
    required this.uid,
    required this.taskId,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        appName: 'TO DO APP', // Tên ứng dụng của bạn
        slogan: 'All in one!', // Slogan của ứng dụng
        actions: [
          IconButton(
            icon: Icon(Icons.edit),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => EditTask(uid: uid, taskId: taskId),
                ),
              );
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Description:',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 5),
            Text(description),
            SizedBox(height: 10),
            StreamBuilder(
              stream: FirebaseFirestore.instance
                  .collection('tasks')
                  .doc(uid)
                  .collection('mytasks')
                  .doc(taskId)
                  .snapshots(),
              builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return CircularProgressIndicator();
                } else {
                  var data = snapshot.data!.data() as Map<String, dynamic>;
                  var deadline = data['deadline'] != null
                      ? (data['deadline'] as Timestamp).toDate()
                      : DateTime.now();
                  String formattedDeadline =
                      DateFormat('dd/MM/yyyy').format(deadline);
                  return Text(
                    'DEADLINE: $formattedDeadline',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  );
                }
              },
            ),
          ],
        ),
      ),
    );
  }
}
