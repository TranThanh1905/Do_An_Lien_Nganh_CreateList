import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'appbar.dart'; // Import CustomAppBar

class EditTask extends StatefulWidget {
  final String uid;
  final String taskId;

  const EditTask({Key? key, required this.uid, required this.taskId})
      : super(key: key);

  @override
  _EditTaskState createState() => _EditTaskState();
}

class _EditTaskState extends State<EditTask> {
  late TextEditingController _titleController;
  late TextEditingController _descriptionController;
  late DateTime _selectedDeadline; // Deadline variable
  String _selectedCategory = 'TODO'; // Default category

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController();
    _descriptionController = TextEditingController();
    _selectedDeadline = DateTime.now(); // Set initial value for deadline
    loadTaskData();
  }

  void loadTaskData() async {
    DocumentSnapshot taskSnapshot = await FirebaseFirestore.instance
        .collection('tasks')
        .doc(widget.uid)
        .collection('mytasks')
        .doc(widget.taskId)
        .get();

    Map<String, dynamic> taskData = taskSnapshot.data() as Map<String, dynamic>;
    setState(() {
      _titleController.text = taskData['title'];
      _descriptionController.text = taskData['description'];
      _selectedCategory = taskData['category']; // Load category from Firestore
      _selectedDeadline = taskData['deadline'] != null
          ? (taskData['deadline'] as Timestamp).toDate()
          : DateTime.now(); // Load deadline from Firestore
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        appName: 'TO DO APP', // Tên ứng dụng của bạn
        slogan: 'All in one!', // Slogan của ứng dụng
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextFormField(
              controller: _titleController,
              decoration: InputDecoration(labelText: 'Title'),
            ),
            TextFormField(
              controller: _descriptionController,
              decoration: InputDecoration(labelText: 'Description'),
            ),
            SizedBox(height: 20),
            Row(
              children: [
                Text('Deadline: '),
                IconButton(
                  icon: Icon(Icons.calendar_today),
                  onPressed: () {
                    _selectDeadline(context);
                  },
                ),
                Text(DateFormat('dd/MM/yyyy')
                    .format(_selectedDeadline)), // Display selected deadline
              ],
            ),
            SizedBox(height: 20),
            DropdownButtonFormField(
              value: _selectedCategory,
              items: ['TODO', 'DOING', 'DONE'].map((category) {
                return DropdownMenuItem(
                  value: category,
                  child: Text(category),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  _selectedCategory = value.toString();
                });
              },
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: saveChanges,
              child: Text('Save Changes'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _selectDeadline(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDeadline,
      firstDate: DateTime.now(),
      lastDate: DateTime(2101),
    );
    if (picked != null && picked != _selectedDeadline)
      setState(() {
        _selectedDeadline = picked;
      });
  }

  void saveChanges() async {
    await FirebaseFirestore.instance
        .collection('tasks')
        .doc(widget.uid)
        .collection('mytasks')
        .doc(widget.taskId)
        .update({
      'title': _titleController.text,
      'description': _descriptionController.text,
      'deadline': _selectedDeadline, // Update deadline in Firestore
      'category': _selectedCategory, // Update category in Firestore
    });
    Navigator.pop(context); // Go back to previous screen after saving
  }
}
