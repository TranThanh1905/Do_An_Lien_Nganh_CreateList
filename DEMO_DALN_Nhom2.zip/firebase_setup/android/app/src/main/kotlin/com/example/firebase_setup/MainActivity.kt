package com.example.firebase_setup

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
